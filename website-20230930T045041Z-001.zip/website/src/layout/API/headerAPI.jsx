const HeaderAPI = [
    {
        id:1,
        image:'img/Deloitte.png',
       
    },
    {
        id:2,
        image:'img/SONY.png',
    },
    {
        id:3,
        image:'img/NFL.png',
    },
    {
        id:4,
        image:'img/timewarnercable.png',
    },
    {
        id:5,
        image:'img/sothebys.png',
    },
    {
        id:6,
        image:'img/Volvo.png',
    }
]

export default HeaderAPI