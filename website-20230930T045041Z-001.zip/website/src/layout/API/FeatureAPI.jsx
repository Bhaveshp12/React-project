const FeatureAPI = [
    {
        id:1,
        title:"Web & Mobile",
        image:"img/mobile.gif",
    },
    {
        id:2,
        title:"Automated Workflows",
        image:"img/mobile.gif",
    },
    {
        id:3,
        title:"Meeting Scheduling",
        image:"img/mobile.gif",
    },
    {
        id:4,
        title:"Data Visualization",
        image:"img/mobile.gif",
    },
    {
        id:5,
        title:"Social Collaboratione",
        image:"img/mobile.gif",
    },
    {
        id:6,
        title:"Task Management",
        image:"img/mobile.gif",
    },
    {
        id:7,
        title:"Granular Access",
        image:"img/mobile.gif",
    },
    {
        id:8,
        title:"Calendar",
        image:"img/mobile.gif",
    },
    {
        id:9,
        title:"Unlimited Storage",
        image:"img/mobile.gif",
    },
    {
        id:10,
        title:"Personal Dashboards",
        image:"img/mobile.gif",
    },
    {
        id:11,
        title:"Connected CRM",
        image:"img/mobile.gif",
    },
    {
        id:12,
        title:"Project Management",
        image:"img/mobile.gif",
    },
    {
        id:13,
        title:"Integrated Chat",
        image:"img/mobile.gif",
    },
    {
        id:14,
        title:"Full Customization",
        image:"img/mobile.gif",
    }
]
export default FeatureAPI